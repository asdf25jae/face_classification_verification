import torch 
import numpy as np 
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import torchvision
import torch.nn.functional as F 
from PIL import Image
import os, sys, time, csv
from torch.utils.data import DataLoader, Dataset  
from torch.autograd import Variable 
import hyperparams as hp 


## resnet model ## 
## resnet.py ## 


kernel_size = hp.kernel_size
res_block_ksize = hp.res_block_ksize
relu = F.relu
blocks_per_layer = hp.blocks_per_layer
input_in_channels = hp.input_in_channels
stride = hp.stride
padding = hp.padding
channels = hp.channels
final_layer_kernel_size = hp.final_layer_kernel_size

## weight init function ## 

def init_weights(m):
    if type(m) == nn.Linear:
        torch.nn.init.xavier_uniform_(m.weight)
        m.bias.data.fill_(0.01)


## basic block, for resnet ## 

class ResBlock(nn.Module):

    def __init__(self, in_channels, out_channels, stride=1):
        # in_channels = in_planes
        # out_channels = planes : how many channels produced by convolution
        super(ResBlock, self).__init__()
        self.expansion = 1
        self.conv1_layer = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=False)
        self.bn1_layer = nn.BatchNorm2d(out_channels)
        self.conv2_layer = nn.Conv2d(out_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=False)
        self.bn2_layer = nn.BatchNorm2d(out_channels)
        
        if stride == 1 and in_channels == self.expansion*out_channels:
            self.skip = nn.Sequential()
        else: 
            self.skip = nn.Sequential(nn.Conv2d(in_channels, self.expansion*out_channels, kernel_size=res_block_ksize, 
            stride=stride, bias=False), nn.BatchNorm2d(self.expansion*out_channels))


        def forward(self, x): 
            first_out = relu(self.bn1_layer(self.conv1_layer))
            second_out = self.bn2_layer(self.conv2_layer)
            res_skip = self.skip
            return F.relu(second_out + res_skip)


class ResNet(nn.Module):
    # ResNet architecture based on paper 

    def __init__(self, res_block, num_of_blocks, num_of_final_classes): 
        super(ResNet, self).__init__() 
        self.in_channels = 64

        self.channels = channels
        self.conv1_layer = nn.Conv2d(channels[0], self.in_channels, kernel_size=kernel_size, stride=stride, padding=1, bias=False)
        self.bn1_layer = nn.BatchNorm2d(self.in_channels)

        self.layer1 = self.create_layer(block, self.channels[1], num_blocks[0], stride=1)
        self.layer2 = self.create_layer(block, self.channels[2], num_blocks[1], stride=2)
        self.layer3 = self.create_layer(block, self.channels[3], num_blocks[2], stride=2)
        self.layer4 = self.create_layer(block, self.channels[4], num_blocks[3], stride=2)

        self.hiddens = [self.layer1, self.layer2, self.layer3, self.layer4]
        self.linear = nn.Linear(self.channels[5]*block.expansion, num_classes)

    def create_layer(self, block, num_channels, num_blocks, stride): 
        strides = [stride] + [1]*(num_blocks - 1)
        layer_sizes = []
        # initialize empty strides and layer sizes array values 
        # now fill in with appropriate blocks 
        for stride in strides: 
            n_block = block(self.in_channels, num_channels, stride)
            self.in_channels = num_channels * block.expansion
            layers.append(n_block)
        output_layer = nn.Sequential(*layers)
        return output_layer

    def forward(self, x): 
        self.x = x 
        first_out = F.relu(self.bn1(self.conv1(x)))
        for layer in self.hiddens:
            out = layer(out)
        out = F.avg_pool2d(out, final_layer_kernel_size)
        out = out.view(out.size(0), -1)
        out = self.linear(out)
        return out

def ResNet34():
    out = ResNet(ResBlock, blocks_per_layer)
    return out


def main(): 
    #net = ResNet34() # our resnet model 

    return None 

if __name__ == "__main__": 
    main()